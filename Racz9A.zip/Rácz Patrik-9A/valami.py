import random
lista=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]
print(lista)

lista2=[szam for szam in range(1,31)]
print(lista2)

lista3=[i for i in range(1,31) if i%2==0]
print(lista3)

lista4=[a for a in range(1,31) if a%2==1]
print(lista4)


lista5=[]
for _ in range(20):
    lista5.append(random.randint(1,50))
print(lista5)

lista6=[random.randint(1,50) for _ in range(20)]
print(lista6)
    
egyedi=[]
for i in lista6:
    if i not in egyedi:
        egyedi.append(i)
print(egyedi)

halmaz=set(lista)
egyedi=list(halmaz)
print(type(egyedi))

h={1,1,4,5,9,6,23,5,85,5,5,5,45,5,5}
print(h)

