import random
n=10
lista=[random.randint(1,50) for _ in range(n)]
print(lista)
for i,e in enumerate(lista):
    print(lista[i],lista[i+1])
